# officeACE 数据浏览器

在本地网页里浏览 `dd/hh/mm/*.json` 格式的回流数据。数据根目录在页面上填写；数据文件由本机 Python 服务读取。

## 启动

需要 Python 3.9 或更新版本，无需安装 npm / pip 依赖。

```bash
cd /Users/xinfanchen/项目资料/华为实习/数据准备/officeACE/data-web
python3 server.py
```

浏览器打开 <http://127.0.0.1:8766>。macOS 也可以双击 `start.command`；命令行可以使用 `./start.sh`。终端按 `Ctrl+C` 停止。

可选启动参数：

```bash
python3 server.py --port 8767
python3 server.py --data-root /absolute/path/to/data
```

## 使用

1. 在页面填写数据根目录的绝对路径，点击扫描。根目录是 `dd` 的上一级，例如：

   ```text
   /data/officeACE/
   ├── 18/
   │   └── 23/
   │       └── 59/events.json
   └── 19/
       ├── 08/
       │   └── 00/events.json
       └── 09/
           └── 30/events.json
   ```

2. 设置起止日、时、分。时间区间按照目录时间连续比较，包含两端，支持跨小时、跨天。例如 `18 / 23 / 59 → 19 / 08 / 00` 会包含这两个分钟目录。
3. 在“字段筛选”里打开字段选择框，搜索字段名并选择完整路径，然后输入关键字。点击“添加条件”可以组合多个字段，最多 20 个条件；多个条件和目录时间范围同时生效。字段筛选和左侧展示字段的勾选相互独立。
4. 在左侧字段树选择展示字段。对象、数组及其子字段都有复选框；勾选父级会选择其所有子字段，部分选中时显示半选状态。可搜索字段名。
5. 在表格或 JSON 视图查看选择的字段，翻页浏览结果。展开单条记录可查看投影后的 JSON；导出仅包含当前页与当前选中的字段。
6. 文件新增、删除或更新后，重新扫描当前目录。

`dd` 只有日号，没有年月。请将一个月份的数据放在一个根目录下；跨月数据应分别选择根目录。

“包含”匹配不区分大小写；“等于”匹配区分大小写。“区间”支持任意字段的数字或 ISO 日期时间，包含两个端点，也可以只填写一端。数字两端应与源数据使用相同单位；日期建议显式带时区，例如 `2026-10-19T09:00:00+08:00`。未带时区的日期按 UTC 解释。空关键字或两端都为空的区间不参与筛选。

例如真实记录为：

```json
{
  "start": "2026-10-20T09:00:00+08:00",
  "resourceAttributes": {
    "host.name": "company-pc",
    "user.id": "employee-01"
  }
}
```

选择 `resourceAttributes["host.name"]`，再输入 `company-pc` 即可匹配。添加第二个条件并选择 `resourceAttributes["user.id"]` 可以同时筛选用户。

路径中的点号有明确区别：`resourceAttributes["host.name"]` 表示名为 `host.name` 的一个键；`resourceAttributes.host.name` 表示 `host` 对象下的 `name`。字段选择器直接使用扫描得到的完整路径，不会把点号键错误拆开。数组元素路径显示 `[]`，例如 `events[].attributes["user.id"]`；该数组中任一元素匹配即可，多次命中不会重复记录。多个数组条件各自判断是否存在匹配元素。

布尔值用 `true` / `false`，空值用 `null` 筛选；不存在的字段不会匹配。选择对象或数组整体时，会在它的 JSON 内容中匹配关键字。

## 数据格式

支持以下 UTF-8 JSON 形式，以及 `.jsonl` / `.ndjson` 逐行对象文件：

- 对象数组：`[{"start": "…", "host": {"name": "…"}, "user": {"id": "…"}}]`。
- 包装对象：`{"records": [...]}`，同样识别 `events`、`data`、`items` 数组。
- Elasticsearch 响应：`{"hits": {"hits": [{"_source": {...}}]}}`，展示 `_source` 内容。
- 单条对象记录。顶层已有 `start`、`host`、`user`、`host.name` 或 `user.id` 时，优先视为单条记录，保留其中的嵌套数组。

筛选器和展示字段均通过完整路径区分字段。字段树覆盖当前目录中的全部字段，包含仅在部分记录中出现的字段；切换筛选和翻页时保留已选展示字段。

无法解析的文件或 NDJSON 行会显示警告，其余有效数据仍可查询。目录名可以是一位或两位数字；日为 1–31，时为 0–23，分为 0–59。不跟随数据目录中的符号链接。

## 演示数据

项目附有合成演示数据生成器：

```bash
python3 scripts/generate_demo.py
```

生成 `demo-data/`，默认包含 6 个文件、每个文件 1,000 条记录，共 6,000 条。页面点击演示数据按钮即可加载。所有用户名、主机名、事件均为虚构。演示覆盖嵌套对象、对象数组、数组内嵌套对象、布尔值、空值以及只在部分记录出现的字段。

演示数据也包含 `resourceAttributes["host.name"]` 和 `resourceAttributes["user.id"]`，可以用 `office-bj-01`、`demo-user-001` 验证组合筛选。

## 更新已有的内网版本

1. 更新 `server.py` 和整个 `public/` 目录，保留内网电脑自己的数据目录与 `.cache/`。
2. 停止旧的 Python 服务，再运行 `python3 server.py`，并刷新网页。仅更新前端而不重启后端时，页面会提示版本不支持。
3. 扫描原来的数据根目录，再从字段选择器选择完整嵌套路径。已有记录索引可以继续使用，新增缓存表会自动创建，不需要删除旧索引。

首次筛选某个字段时，后端仅为当前时间范围涉及的文件建立字段索引；翻页和再次筛选复用索引。扩大时间范围时补充索引；源文件更新或删除后重新扫描，会自动清除相应的过期字段索引。整个过程在内网电脑本地完成，无需上传数据，也无需下载依赖。

## 本地实现

- `server.py`：HTTP 服务、文件扫描、SQLite 索引、查询与分页。
- `public/`：原生 HTML / CSS / JavaScript 页面。
- `scripts/generate_demo.py`：可重复生成的合成数据。
- `tests/`：后端集成测试。
- `.cache/`：可重建的本地索引，含原始记录的副本；停止服务后可以删除。

浏览器每次只接收当前页的记录。扫描按文件读取并写入 SQLite，避免把整个数据集同时放进内存；单个 JSON 文件仍需能放入内存。索引在重新扫描时更新。服务默认监听本机 `127.0.0.1`，页面资源和数据查询均由本地提供。

## 验证

```bash
python3 -m unittest discover -s tests -v
node --check public/app.js
node --test tests/test_projection.js
node --test tests/test_filters.js
```
